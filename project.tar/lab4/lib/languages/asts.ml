module Marked = Ast.Make (Mark)
module Tagged = Ast.Make (Type.Tag)