open Core
let run () =
  print_endline "Testing graph...";
  Test_graph.run ()